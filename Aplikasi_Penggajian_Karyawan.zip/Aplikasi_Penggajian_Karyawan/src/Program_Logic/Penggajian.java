/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Program_Logic;

import GUI.Data_Search2;
import GUI.Form_Karyawan;
import com.toedter.calendar.JDateChooser;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import koneksiDB.koneksi;

/**
 *
 * @author LENOVO
 */
public class Penggajian extends Lembur{
    public static String vTgl;
    public static int vGp,vGl,vT,vP,vGb;
    public static void createModel(JTable tbl){
        model = new DefaultTableModel();
        tbl.setModel(model);
        model.addColumn("ID");
        model.addColumn("TglGaji");
        model.addColumn("Nama");
        model.addColumn("Jabatan");
        model.addColumn("Golongan");
        model.addColumn("GajiPokok");
        model.addColumn("GajiLembur");
        model.addColumn("Tunjangan");
        model.addColumn("Potongan");
        model.addColumn("GajiBersih");
    }
    public static void getData(JComboBox<String> ktg,JTextField cr){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        String k = (String)ktg.getSelectedItem();
        String c = cr.getText();
        try{
            st = (Statement) koneksi.getKoneksi().createStatement();
            String sql = "SELECT * FROM penggajian WHERE "+k+" like '%"+c+"%'";
            ResultSet res = st.executeQuery(sql);
            while(res.next()){
                Object[] obj = new Object[10];
                obj[0] = res.getString("gajiID");
                obj[1] = res.getString("tgl");
                obj[2] = res.getString("nama");
                obj[3] = res.getString("jabatan");
                obj[4] = res.getString("golongan");
                obj[5] = res.getString("gapok");
                obj[6] = res.getString("gaji_lembur");
                obj[7] = res.getString("tunjangan");
                obj[8] = res.getString("potongan");
                obj[9] = res.getString("gaji_bersih");
                model.addRow(obj);
            }
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, err.getMessage());
        }
    }
    public static void loadData(JTextField nm,JDateChooser tg,JTextField gp,JTextField gl,JTextField pt, JTextField tj,JTextField jbt, JTextField gol){
        vNm = nm.getText();
        String tampilan ="yyyy-MM-dd" ; 
        SimpleDateFormat fm = new SimpleDateFormat(tampilan); 
        vTgl = String.valueOf(fm.format(tg.getDate()));
        vGp = Integer.parseInt(gp.getText());
        vGl = Integer.parseInt(gl.getText());
        vT = Integer.parseInt(tj.getText());
        vP = Integer.parseInt(pt.getText());
        vGb = (vGp+vGl+vT) - vP;
        vJbt = jbt.getText();
        vGol = gol.getText();
    }
    public static void save(JTextField nm,JDateChooser tg,JTextField gp,JTextField gl,JTextField pt, JTextField tj,JTextField jbt, JTextField gol){
        loadData(nm, tg, gp, gl, pt, tj, jbt, gol);
        try{
        st = (Statement)koneksi.getKoneksi().createStatement();
        String sql = "Insert into penggajian(tgl,nama,jabatan,golongan,gapok,gaji_lembur,tunjangan,potongan,gaji_bersih)"
                +"values('"+vTgl+"','"+vNm+"','"+vJbt+"','"+vGol+"','"+vGp+"','"+vGl+"','"+vT+"','"+vP+"','"+vGb+"')";
        PreparedStatement p = (PreparedStatement)koneksi.getKoneksi().prepareStatement(sql);
        p.executeUpdate(sql);
        getData();
        reset(nm, tg, gp, gl, pt, tj, jbt, gol);
        nm.requestFocus();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiSimpan!");
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, "Data Gagal DiSimpan!");
            reset(nm, tg, gp, gl, pt, tj, jbt, gol);
        }
    }
    public static void reset(JTextField nm,JDateChooser tg,JTextField gp,JTextField gl,JTextField pt, JTextField tj,JTextField jbt, JTextField gol){
        vId = 0;
        vNm  = "";
        vTgl = "";
        vGp  = 0;
        vGl  = 0;
        vT  = 0;
        vP  = 0;
        vGb  = 0;
        vJbt = "";
        vGol = "";
        nm.setText(null);
        tg.setDate(null);
        jbt.setText(null);
        gol.setText(null);
        gp.setText(null);
        gl.setText(null);
        tj.setText(null);
        pt.setText(null);
    }
    public static void selectData(JTextField nm,JDateChooser tg,JTextField gp,JTextField gl,JTextField pt, JTextField tj,JTextField jbt, JTextField gol, JTable tbl){
        int i = tbl.getSelectedRow();
        if(i == -1){
            JOptionPane.showMessageDialog(null, "Tidak ada data terpilih!");
            return;
        }
        nm.setText(""+model.getValueAt(i, 2));
         try {
            int index = tbl.getSelectedRow();
            Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(index, 1));
            tg.setDate(date);
        } catch (ParseException ex) {
            Logger.getLogger(Form_Karyawan.class.getName()).log(Level.SEVERE, null, ex);
        }
        jbt.setText(""+model.getValueAt(i, 3));
        gol.setText(""+model.getValueAt(i, 4));
        gp.setText(""+model.getValueAt(i, 5));
        gl.setText(""+model.getValueAt(i, 6));
        tj.setText(""+model.getValueAt(i, 7));
        pt.setText(""+model.getValueAt(i, 8));
        vGb = Integer.valueOf(""+model.getValueAt(i, 9));
        vId = Integer.valueOf(""+model.getValueAt(i, 0));
    }
    public static void update(JTextField nm,JDateChooser tg,JTextField gp,JTextField gl,JTextField pt, JTextField tj,JTextField jbt, JTextField gol){
        loadData(nm, tg, gp, gl, pt, tj, jbt, gol);
        try{
           st = (Statement)koneksi.getKoneksi().createStatement();
           String sql = "update penggajian set tgl = '"+vTgl+"',"
                   + "nama='"+vNm+"',"
                   + "jabatan='"+vJbt+"',"
                   + "golongan='"+vGol+"',"
                   + "gapok='"+vGp+"',"
                   + "gaji_lembur='"+vGl+"',"
                   + "tunjangan='"+vT+"',"
                   + "potongan='"+vP+"',"
                   + "gaji_bersih='"+vGb+"' where gajiID='"+vId+"'";
        PreparedStatement p = (PreparedStatement)koneksi.getKoneksi().prepareStatement(sql);
        p.executeUpdate();
        getData();
        reset(nm, tg, gp, gl, pt, tj, jbt, gol);
        nm.requestFocus();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiUpdate");
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, "Data Gagal DiUpdate!");
            reset(nm, tg, gp, gl, pt, tj, jbt, gol);
        }
    }
    public static void delete(JTextField nm,JDateChooser tg,JTextField gp,JTextField gl,JTextField pt, JTextField tj,JTextField jbt, JTextField gol){
        //loadData();
        int psn = JOptionPane.showConfirmDialog(null, "Anda yakin ingin menghapus data ini?","Konfirmasi",
                JOptionPane.OK_CANCEL_OPTION);
        if(psn == JOptionPane.OK_OPTION){
            try{
                st = (Statement) koneksi.getKoneksi().createStatement();
                String sql = "Delete From penggajian Where gajiID='"+vId+"'";
                PreparedStatement p =(PreparedStatement) koneksi.getKoneksi().prepareCall(sql);
                p.executeUpdate();
                getData();
                reset(nm, tg, gp, gl, pt, tj, jbt, gol);
                nm.requestFocus();
                JOptionPane.showMessageDialog(null, "Data Berhasil DiHapus");
            }catch(SQLException err){
                JOptionPane.showMessageDialog(null, "Data Gagal DiHapus!");
                reset(nm, tg, gp, gl, pt, tj, jbt, gol);
            }
        }
    }
    public static void refresh(JComboBox<String> ktg,JTextField cr){
        cr.setText(null);
        getData(ktg, cr);
    }
    public static void searchKaryawan(GUI.Form_Penggajian Form,JTextField gp){
        GUI.Data_Search2 DS = new GUI.Data_Search2();
        DS.fP = Form;
        DS.setVisible(true);
        DS.setResizable(false);
        gp.requestFocus();
    }
    public static void searchGaji(GUI.Form_Penggajian Form,JTextField tj){
        GUI.Data_Search_Lmb DSL = new GUI.Data_Search_Lmb();
        DSL.fP = Form;
        DSL.setVisible(true);
        DSL.setResizable(false);
        tj.requestFocus();
    }
}
