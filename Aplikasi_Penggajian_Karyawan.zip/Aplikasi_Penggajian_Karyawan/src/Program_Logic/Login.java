/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Program_Logic;

import GUI.Form_Utama;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import koneksiDB.koneksi;

/**
 *
 * @author LENOVO
 */
public class Login {
    public static Statement st;
    public static void login(JTextField user, JPasswordField pass, JFrame Form){
        try {
            String sql = "SELECT * FROM user WHERE username = '" + user.getText() + "' AND password = '" + pass.getText() + "'";
            st = koneksi.getKoneksi().createStatement();
            ResultSet rsLogin = st.executeQuery(sql);

            if ( rsLogin.next()){
                JOptionPane.showMessageDialog(null, "Login Berhasil!");
                new Form_Utama().setVisible(true);
                Form.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Maaf, Username / Password salah!");
                user.requestFocus();
            }
        } catch (SQLException e) {
        }
    }
    public static void cancel(){
        int psn = JOptionPane.showConfirmDialog(null, "Anda yakin membatalkan Login?","Konfirmasi",
            JOptionPane.OK_CANCEL_OPTION);
        if(psn == JOptionPane.OK_OPTION){
            System.exit(0);
        }
    }
}
