/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Program_Logic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import koneksiDB.koneksi;

/**
 *
 * @author LENOVO
 */
public class Data_Search_Lmb extends Data_Search{
    public static void createModel(JTable tbl){
        model = new DefaultTableModel();
        tbl.setModel(model);
        model.addColumn("ID");
        model.addColumn("Nama");
        model.addColumn("Jabatan");
        model.addColumn("Golongan");
        model.addColumn("JmlJam");
        model.addColumn("GajiPerJam");
        model.addColumn("Total");
    }
    public static void getData(JComboBox<String> ktg,JTextField cr){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        String k = (String)ktg.getSelectedItem();
        String c = cr.getText();
        try{
            st = (Statement) koneksi.getKoneksi().createStatement();
            String sql = "SELECT * FROM lembur WHERE "+k+" like '%"+c+"%'";
            ResultSet res = st.executeQuery(sql);
            while(res.next()){
                Object[] obj = new Object[7];
                obj[0] = res.getString("lemburID");
                obj[1] = res.getString("nama");
                obj[2] = res.getString("jabatan");
                obj[3] = res.getString("golongan");
                obj[4] = res.getString("jml_jam");
                obj[5] = res.getString("gaji_perjam");
                obj[6] = res.getString("total");
                
                model.addRow(obj);
            }
        }catch(SQLException err){
                JOptionPane.showMessageDialog(null, err.getMessage());
        }
    }
    
    public static void refresh(JTextField cr, JComboBox<String> ktg){
        cr.setText(null);
        getData(ktg, cr);
    }
}

