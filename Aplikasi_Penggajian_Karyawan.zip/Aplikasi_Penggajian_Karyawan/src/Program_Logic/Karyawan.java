/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Program_Logic;

import GUI.Form_Karyawan;
import com.toedter.calendar.JDateChooser;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import koneksiDB.koneksi;

/**
 *
 * @author LENOVO
 */
public class Karyawan extends Data_Search{
    public static String vNm,vTgl,vJk,vAl,vJbt,vGol,vHp;
    public static void refresh(JTextField cr, JComboBox<String> ktg){
        cr.setText(null);
        getData(ktg, cr);
    }

    public static void loadData(JTextField nm,JRadioButton lk, JDateChooser tg, JTextArea almt, JTextField hp, JComboBox<String> jbt, JComboBox<String> gol){
        vNm = nm.getText();
        String tampilan ="yyyy-MM-dd" ; 
        SimpleDateFormat fm = new SimpleDateFormat(tampilan); 
        vTgl = String.valueOf(fm.format(tg.getDate()));
        if(lk.isSelected()){
            vJk = "L";
        }else{
            vJk = "P";
        }
        vAl = almt.getText();
        vHp = hp.getText();
        vJbt = (String)jbt.getSelectedItem();
        vGol = (String)gol.getSelectedItem();
    }
    public static void save(JTextField nm,JRadioButton lk, JDateChooser tg, JTextArea almt, JTextField hp, JComboBox<String> jbt, JComboBox<String> gol,JComboBox ktg, JTextField cr){
        loadData(nm, lk, tg, almt, hp, jbt, gol);
        try{
        st = (Statement)koneksi.getKoneksi().createStatement();
        String sql = "Insert into karyawan(nama,tgl_lahir,jk,alamat,noHP,jabatan,golongan)"
                +"values('"+vNm+"','"+vTgl+"','"+vJk+"','"+vAl+"','"+vHp+"','"+vJbt+"','"+vGol+"')";
        PreparedStatement p = (PreparedStatement)koneksi.getKoneksi().prepareStatement(sql);
        p.executeUpdate(sql);
        getData(ktg, cr);
        reset(nm, lk, lk, tg, almt, hp, jbt, gol);
        nm.requestFocus();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiSimpan!");
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, "Data Gagal DiSimpan!");
            reset(nm, lk, lk, tg, almt, hp, jbt, gol);
        }
    }
    public static void reset(JTextField nm,JRadioButton lk,JRadioButton pr, JDateChooser tg, JTextArea almt, JTextField hp, JComboBox<String> jbt, JComboBox<String> gol){
        vId = 0;
        vNm  = "";
        vTgl = "";
        vJk  = "";
        vAl  = "";
        vHp  = "";
        vJbt = "";
        vGol = "";
        nm.setText(null);
        tg.setDate(null);
        pr.setSelected(false);
        lk.setSelected(false);
        almt.setText(null);
        hp.setText(null);
        jbt.setSelectedIndex(0);
        gol.setSelectedIndex(0);
    }
    public static void selectData(JTable tbl,JTextField nm, JDateChooser tg, JRadioButton lk,JRadioButton pr, JTextArea almt, JTextField hp, JComboBox<String> jbt, JComboBox<String> gol){
        int i = tbl.getSelectedRow();
        if(i == -1){
            JOptionPane.showMessageDialog(null, "Tidak ada data terpilih!");
            return;
        }
        nm.setText(""+model.getValueAt(i, 1));
         try {
            int index = tbl.getSelectedRow();
            Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(index, 2));
            tg.setDate(date);
        } catch (ParseException ex) {
            Logger.getLogger(Form_Karyawan.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(model.getValueAt(i, 3).equals("P")){
            pr.setSelected(true);
            lk.setSelected(false);
        }else{
            pr.setSelected(false);
            lk.setSelected(true);
        }
        almt.setText(""+model.getValueAt(i, 4));
        hp.setText(""+model.getValueAt(i, 5));
        jbt.setSelectedItem(""+model.getValueAt(i, 6));
        gol.setSelectedItem(""+model.getValueAt(i, 7));
        vId = Integer.valueOf(""+model.getValueAt(i, 0));
    }
    public static void update(JComboBox ktg, JTextField cr,JTextField nm,JRadioButton lk, JDateChooser tg, JTextArea almt, JTextField hp, JComboBox<String> jbt, JComboBox<String> gol){
        loadData(nm, lk, tg, almt, hp, jbt, gol);
        try{
           st = (Statement)koneksi.getKoneksi().createStatement();
           String sql = "update karyawan set nama = '"+vNm+"',"
                   + "tgl_lahir='"+vTgl+"',"
                   + "jk='"+vJk+"',"
                   + "alamat='"+vAl+"',"
                   + "noHP='"+vHp+"',"
                   + "jabatan='"+vJbt+"',"
                   + "golongan='"+vGol+"' where karyawanID='"+vId+"'";
        PreparedStatement p = (PreparedStatement)koneksi.getKoneksi().prepareStatement(sql);
        p.executeUpdate();
        getData(ktg, cr);
        reset(nm, lk, lk, tg, almt, hp, jbt, gol);
        nm.requestFocus();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiUpdate");
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, "Data Gagal DiUpdate!");
            reset(nm, lk, lk, tg, almt, hp, jbt, gol);
        }
    }
    public static void delete(JComboBox ktg, JTextField cr,JTextField nm,JRadioButton lk, JDateChooser tg, JTextArea almt, JTextField hp, JComboBox<String> jbt, JComboBox<String> gol){
        //loadData();
        int psn = JOptionPane.showConfirmDialog(null, "Anda yakin ingin menghapus data ini?","Konfirmasi",
                JOptionPane.OK_CANCEL_OPTION);
        if(psn == JOptionPane.OK_OPTION){
            try{
                st = (Statement) koneksi.getKoneksi().createStatement();
                String sql = "Delete From karyawan Where karyawanID='"+vId+"'";
                PreparedStatement p =(PreparedStatement) koneksi.getKoneksi().prepareCall(sql);
                p.executeUpdate();
                getData(ktg, cr);
                reset(nm, lk, lk, tg, almt, hp, jbt, gol);
                nm.requestFocus();
                JOptionPane.showMessageDialog(null, "Data Berhasil DiHapus");
            }catch(SQLException err){
                JOptionPane.showMessageDialog(null, "Data Gagal DiHapus!");
                reset(nm, lk, lk, tg, almt, hp, jbt, gol);
            }
        }
    }
}
