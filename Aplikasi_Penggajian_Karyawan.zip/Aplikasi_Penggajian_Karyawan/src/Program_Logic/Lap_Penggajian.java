/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Program_Logic;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import koneksiDB.koneksi;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author LENOVO
 */
public class Lap_Penggajian extends Penggajian{
    private static JasperReport jasperReport;
    private static JasperDesign jasperDesign;
    private static JasperPrint jasperPrint;
    private static Map param = new HashMap();
    public static void getData(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        try{
            st = (Statement) koneksi.getKoneksi().createStatement();
            String sql = "SELECT * FROM penggajian";
            ResultSet res = st.executeQuery(sql);
            while(res.next()){
                Object[] obj = new Object[10];
                obj[0] = res.getString("gajiID");
                obj[1] = res.getString("tgl");
                obj[2] = res.getString("nama");
                obj[3] = res.getString("jabatan");
                obj[4] = res.getString("golongan");
                obj[5] = res.getString("gapok");
                obj[6] = res.getString("gaji_lembur");
                obj[7] = res.getString("tunjangan");
                obj[8] = res.getString("potongan");
                obj[9] = res.getString("gaji_bersih");
                model.addRow(obj);
            }
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, err.getMessage());
        }
    }
    public static void cetak(){
        try{
            File reprt = new File("src/Jasper/report2.jrxml");
            jasperDesign = JRXmlLoader.load(reprt);
            param.clear();
            jasperReport = JasperCompileManager.compileReport(jasperDesign);
            jasperPrint = JasperFillManager.fillReport(jasperReport,param,koneksi.getKoneksi());
            JasperViewer.viewReport(jasperPrint,false);
            JasperPrintManager.printReport(jasperPrint, true);
        }catch(JRException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
