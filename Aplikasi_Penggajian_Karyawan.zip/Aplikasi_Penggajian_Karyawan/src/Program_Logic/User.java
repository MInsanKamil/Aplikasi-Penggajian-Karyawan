/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Program_Logic;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import koneksiDB.koneksi;

/**
 *
 * @author LENOVO
 */
public class User extends Login{
    public static DefaultTableModel model;
    public static String vUser,vPass;
    public static int vId;
    public static void createModel(JTable tbl){
        model = new DefaultTableModel();
        tbl.setModel(model);
        model.addColumn("No ID");
        model.addColumn("Username");
        model.addColumn("Password");
    }
    public static void getData(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        try{
            st = (Statement) koneksi.getKoneksi().createStatement();
            String sql = "SELECT * FROM user";
            ResultSet res = st.executeQuery(sql);
            while(res.next()){
                Object[] obj = new Object[3];
                obj[0] = res.getString("noID");
                obj[1] = res.getString("username");
                obj[2] = res.getString("password");
                model.addRow(obj);
            }
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, err.getMessage());
        }
    }
    public static void loadData(JTextField user, JPasswordField pass){
        vUser = user.getText();
        vPass = pass.getSelectedText();
    }
    public static void save(JTextField user, JPasswordField pass){
        loadData(user, pass);
        try{
        st = (Statement)koneksi.getKoneksi().createStatement();
        String sql = "Insert into user(username,password)"
                +"values('"+vUser+"','"+vPass+"')";
        PreparedStatement p = (PreparedStatement)koneksi.getKoneksi().prepareStatement(sql);
        p.executeUpdate(sql);
        getData();
        reset(user, pass);
        user.requestFocus();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiSimpan!");
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, "Data Gagal DiSimpan!");
            reset(user, pass);
        }
    }
    public static void reset(JTextField user, JPasswordField pass){
        vId = 0;
        vUser  = "";
        vPass = "";
        user.setText(null);
        pass.setText(null);
    }
    public static void selectData(JTextField user, JPasswordField pass,JTable tbl){
        int i = tbl.getSelectedRow();
        if(i == -1){
            JOptionPane.showMessageDialog(null, "Tidak ada data terpilih!");
            return;
        }
        user.setText(""+model.getValueAt(i, 1));
        pass.setText(""+model.getValueAt(i, 2));
        vId = Integer.valueOf(""+model.getValueAt(i, 0));
    }
    public static void update(JTextField user, JPasswordField pass){
        loadData(user, pass);
        try{
           st = (Statement)koneksi.getKoneksi().createStatement();
           String sql = "update user set username = '"+vUser+"',"
                   + "password='"+vPass+"' where noID='"+vId+"'";
        PreparedStatement p = (PreparedStatement)koneksi.getKoneksi().prepareStatement(sql);
        p.executeUpdate();
        getData();
        reset(user, pass);
        user.requestFocus();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiUpdate");
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, "Data Gagal DiUpdate!");
            reset(user, pass);
        }
    }
    public static void delete(JTextField user, JPasswordField pass){
        //loadData();
        int psn = JOptionPane.showConfirmDialog(null, "Anda yakin ingin menghapus data ini?","Konfirmasi",
                JOptionPane.OK_CANCEL_OPTION);
        if(psn == JOptionPane.OK_OPTION){
            try{
                st = (Statement) koneksi.getKoneksi().createStatement();
                String sql = "Delete From user Where noID='"+vId+"'";
                PreparedStatement p =(PreparedStatement) koneksi.getKoneksi().prepareCall(sql);
                p.executeUpdate();
                getData();
                reset(user, pass);
                user.requestFocus();
                JOptionPane.showMessageDialog(null, "Data Berhasil DiHapus");
            }catch(SQLException err){
                JOptionPane.showMessageDialog(null, "Data Gagal DiHapus!");
                reset(user, pass);
            }
        }
    }
    public static void exit(JFrame Form){
        int konf = JOptionPane.showConfirmDialog(null, "Yakin Ingin menutup Form?","Konfirmasi",JOptionPane.YES_NO_OPTION);
        if(konf == JOptionPane.YES_OPTION){
            Form.dispose();
        } 
    }
}