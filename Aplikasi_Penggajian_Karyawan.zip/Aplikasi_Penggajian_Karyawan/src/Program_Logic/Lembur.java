/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Program_Logic;

import static Program_Logic.Login.st;
import static Program_Logic.User.model;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import koneksiDB.koneksi;

/**
 *
 * @author LENOVO
 */
public class Lembur extends Data_Search_Lmb{
    public static String vNm,vJbt,vGol;
    public static int vJj,vGj,vTot;
    public static void loadData(JTextField nm,JTextField jbt,JTextField gol,JTextField jj, JTextField gj){
        vNm = nm.getText();
        vJbt = jbt.getText();
        vGol = gol.getText();
        vJj = Integer.parseInt(jj.getText());
        vGj = Integer.parseInt(gj.getText());
        vTot = vGj * vJj;
    }
    public static void save(JTextField nm,JTextField jbt,JTextField gol,JTextField jj, JTextField gj){
        loadData(nm, jbt, gol, jj, gj);
        try{
        st = (Statement)koneksi.getKoneksi().createStatement();
        String sql = "Insert into lembur(nama,jabatan,golongan,jml_jam,gaji_perjam,total)"
                +"values('"+vNm+"','"+vJbt+"','"+vGol+"','"+vJj+"','"+vGj+"','"+vTot+"')";
        PreparedStatement p = (PreparedStatement)koneksi.getKoneksi().prepareStatement(sql);
        p.executeUpdate(sql);
        getData();
        reset(nm, jbt, gol, jj, gj);
        nm.requestFocus();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiSimpan!");
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, "Data Gagal DiSimpan!");
            reset(nm, jbt, gol, jj, gj);
        }
    }
    public static void reset(JTextField nm,JTextField jbt,JTextField gol,JTextField jj, JTextField gj){
        vId = 0;
        vNm  = "";
        vJbt = "";
        vGol  = "";
        vJj  = 0;
        vGj = 0;
        vTot = 0;
        nm.setText(null);
        jbt.setText(null);
        gol.setText(null);
        jj.setText(null);
        gj.setText(null);
    }
    public static void selectData(JTextField nm,JTextField jbt,JTextField gol,JTextField jj, JTextField gj, JTable tbl){
        int i = tbl.getSelectedRow();
        if(i == -1){
            JOptionPane.showMessageDialog(null, "Tidak ada data terpilih!");
            return;
        }
        nm.setText(""+model.getValueAt(i, 1));
        jbt.setText(""+model.getValueAt(i, 2));
        gol.setText(""+model.getValueAt(i, 3));
        jj.setText(""+model.getValueAt(i, 4));
        gj.setText(""+model.getValueAt(i, 5));
        vId = Integer.valueOf(""+model.getValueAt(i, 0));
    }
    public static void update(JTextField nm,JTextField jbt,JTextField gol,JTextField jj, JTextField gj){
        loadData(nm, jbt, gol, jj, gj);
        try{
           st = (Statement)koneksi.getKoneksi().createStatement();
           String sql = "update lembur set nama = '"+vNm+"',"
                   + "jabatan='"+vJbt+"',"
                   + "golongan='"+vGol+"',"
                   + "jml_jam='"+vJj+"',"
                   + "gaji_perjam='"+vGj+"',"
                   + "total='"+vTot+"' where lemburID='"+vId+"'";
        PreparedStatement p = (PreparedStatement)koneksi.getKoneksi().prepareStatement(sql);
        p.executeUpdate();
        getData();
        reset(nm, jbt, gol, jj, gj);
        nm.requestFocus();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiUpdate");
        }catch(SQLException err){
            JOptionPane.showMessageDialog(null, "Data Gagal DiUpdate!");
            reset(nm, jbt, gol, jj, gj);
        }
    }
    public static void delete(JTextField nm,JTextField jbt,JTextField gol,JTextField jj, JTextField gj){
        //loadData();
        int psn = JOptionPane.showConfirmDialog(null, "Anda yakin ingin menghapus data ini?","Konfirmasi",
                JOptionPane.OK_CANCEL_OPTION);
        if(psn == JOptionPane.OK_OPTION){
            try{
                st = (Statement) koneksi.getKoneksi().createStatement();
                String sql = "Delete From lembur Where lemburID='"+vId+"'";
                PreparedStatement p =(PreparedStatement) koneksi.getKoneksi().prepareCall(sql);
                p.executeUpdate();
                getData();
                reset(nm, jbt, gol, jj, gj);
                nm.requestFocus();
                JOptionPane.showMessageDialog(null, "Data Berhasil DiHapus");
            }catch(SQLException err){
                JOptionPane.showMessageDialog(null, "Data Gagal DiHapus!");
                reset(nm, jbt, gol, jj, gj);
            }
        }
    }
    
    public static void refresh(JComboBox<String> ktg,JTextField cr){
        cr.setText(null);
        getData(ktg, cr);
    }
    public static void searchKaryawan(GUI.Form_Lembur Form, JTextField jj){
        GUI.Data_Search DS = new GUI.Data_Search();
        DS.fL = Form;
        DS.setVisible(true);
        DS.setResizable(false);    
        jj.requestFocus();
    }
}
