/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Program_Logic;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import koneksiDB.koneksi;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author LENOVO
 */
public class Lap_Karyawan extends Karyawan{
    public static JasperReport jasperReport;
    public static JasperDesign jasperDesign;
    public static JasperPrint jasperPrint;
    public static Map param = new HashMap();
    public static void cetak(){
        try{
            File reprt = new File("src/Jasper/report1.jrxml");
            jasperDesign = JRXmlLoader.load(reprt);
            param.clear();
            jasperReport = JasperCompileManager.compileReport(jasperDesign);
            jasperPrint = JasperFillManager.fillReport(jasperReport,param,koneksi.getKoneksi());
            JasperViewer.viewReport(jasperPrint,false);
            JasperPrintManager.printReport(jasperPrint, true);
        }catch(JRException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public static void getData(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        try{
            st = (Statement) koneksi.getKoneksi().createStatement();
            String sql = "SELECT * FROM karyawan";
            ResultSet res = st.executeQuery(sql);
            while(res.next()){
                Object[] obj = new Object[8];
                obj[0] = res.getString("karyawanID");
                obj[1] = res.getString("nama");
                obj[2] = res.getString("tgl_lahir");
                obj[3] = res.getString("jk");
                obj[4] = res.getString("alamat");
                obj[5] = res.getString("noHP");
                obj[6] = res.getString("jabatan");
                obj[7] = res.getString("golongan");
                
                model.addRow(obj);
            }
        }catch(SQLException err){
                JOptionPane.showMessageDialog(null, err.getMessage());
        }
    }
}
