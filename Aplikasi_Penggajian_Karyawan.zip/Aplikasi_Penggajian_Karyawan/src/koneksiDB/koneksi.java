/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksiDB;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class koneksi {
    private static Connection koneksi;
    public static Connection getKoneksi() { 
            
          try {
           String url = new String();
           String user = new String();
           String password = new String();
           url = "jdbc:mysql://localhost:3306/penggajian";
           user = "root";
           password = "";
           
           DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
           koneksi = DriverManager.getConnection(url,user,password);
                } catch (HeadlessException | SQLException e) {
                    JOptionPane.showMessageDialog(null, "Connection Failed" +e);
                }       
        return koneksi;
    }
    
}
